const fileUpload = require("express-fileupload");
const session = require("express-session");
const bodyParser = require("body-parser");
const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();

const portNumber = 9000;

app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(session({ secret: "secret-key" }));
app.use(fileUpload());

app.set("view engine", "ejs");

app.get("/", (req, res) => {
  const productsData = fs.readFileSync(path.join(__dirname, "products.json"));
  const products = JSON.parse(productsData);
  res.render("index", { products });
});

app.get("/edit/:id", (req, res) => {
  const productsData = fs.readFileSync(path.join(__dirname, "products.json"));
  const products = JSON.parse(productsData);
  const productId = parseInt(req.params.id);
  const product = products.find((p) => p.id === productId);

  if (!product) {
    res.redirect("/");
    return;
  }

  res.render("editProduct", { product });
});

app.post("/update/:id", (req, res) => {
  const productsData = fs.readFileSync(path.join(__dirname, "products.json"));
  const products = JSON.parse(productsData);
  const productId = parseInt(req.params.id);
  const productIndex = products.findIndex((p) => p.id === productId);

  if (productIndex === -1) {
    res.redirect("/");
    return;
  }

  const updatedProduct = {
    id: productId,
    name: req.body.name,
    price: req.body.price,
    is_available: req.body.is_available === "true",
    category: req.body.category_name,
  };

  products[productIndex] = updatedProduct;

  fs.writeFileSync(
    path.join(__dirname, "products.json"),
    JSON.stringify(products, null, 2)
  );

  res.redirect("/");
});

app.get("/delete/:id", (req, res) => {
  const productsData = fs.readFileSync(path.join(__dirname, "products.json"));
  const products = JSON.parse(productsData);
  const recordId = parseInt(req.params.id);
  const recordIndex = products.findIndex((record) => record.id === recordId);
  if (recordIndex !== -1) {
    products.splice(recordIndex, 1);
    fs.writeFileSync("products.json", JSON.stringify(products));
    if (req.xhr) {
      res.json({ success: true });
    } else {
      res.redirect("/index");
    }
  } else {
    res.status(404);
  }
});

app.post("/add-to-cart", (req, res) => {
  const productId = parseInt(req.body.productId);
  const quantity = parseInt(req.body.quantity);

  let cart = req.session.cart;
  if (!cart) {
    cart = [];
    req.session.cart = cart;
  }

  const productIndex = cart.findIndex((item) => item.productId === productId);
  // If The Product Is Already Present In The Cart Then I Am Updating Its Quantity In The Else It Is Adding In The Cart
  if (productIndex !== -1) {
    cart[productIndex].quantity += quantity;
  } else {
    cart.push({ productId: productId, quantity: quantity });
  }

  res.redirect("/cart");
});

app.get("/cart", (req, res) => {
  const productsData = fs.readFileSync(path.join(__dirname, "products.json"));
  const products = JSON.parse(productsData);

  const cart = req.session.cart || [];

  const cartItems = cart.map((item) => {
    const product = products.find((p) => p.id === item.productId);
    const totalPrice = product.price * item.quantity;
    return {
      productId: product.id,
      name: product.name,
      quantity: item.quantity,
      price: product.price,
      totalPrice: totalPrice,
    };
  });

  const cartTotal = cartItems.reduce(
    (total, item) => total + item.totalPrice,
    0
  );

  res.render("cart", { cartItems: cartItems, cartTotal: cartTotal });
});

app.listen(portNumber, () => {
  console.log(`Server Is Running On Port ${portNumber}`);
});